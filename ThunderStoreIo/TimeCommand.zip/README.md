# Time Command

## Installation

Just drag and drop the BepInEx folder to your Lethal Company root folder(Where the Lethal Company.exe is).

## Overview

This is a mod that uses TerminalApi. It allows you to display the current time with the great `time` command. `check time` also works.

